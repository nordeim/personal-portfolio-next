/* =========================================
   LANDING.JS
   OneStopNews — Editorial Landing Page
   ========================================= */

(function () {
  "use strict";

  /* =========================================
     MODULE 1 — SCROLL REVEAL
     ========================================= */

  function initScrollReveal() {
    const sections = document.querySelectorAll(".reveal");

    if (!sections.length) return;

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReducedMotion) {
      sections.forEach(function (section) {
        section.classList.add("visible");
      });
      return;
    }

    const observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.12,
        rootMargin: "0px 0px -40px 0px",
      }
    );

    sections.forEach(function (section) {
      observer.observe(section);
    });
  }

  /* =========================================
     MODULE 2 — STAT COUNTER ANIMATION
     ========================================= */

  function initCounters() {
    const counters = document.querySelectorAll("[data-counter]");

    if (!counters.length) return;

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReducedMotion) {
      counters.forEach(function (counter) {
        var target = parseInt(counter.getAttribute("data-counter"), 10);
        counter.textContent = formatNumber(target);
      });
      return;
    }

    var animated = new Set();

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          if (animated.has(entry.target)) return;

          animated.add(entry.target);
          animateCounter(entry.target);
          observer.unobserve(entry.target);
        });
      },
      {
        threshold: 0.5,
      }
    );

    counters.forEach(function (counter) {
      observer.observe(counter);
    });
  }

  function animateCounter(element) {
    var target = parseInt(element.getAttribute("data-counter"), 10);
    var duration = 1800;
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;

      var elapsed = timestamp - startTime;
      var progress = Math.min(elapsed / duration, 1);

      var eased = easeOutExpo(progress);
      var current = Math.round(eased * target);

      element.textContent = formatNumber(current);

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        element.textContent = formatNumber(target) + "+";
      }
    }

    requestAnimationFrame(step);
  }

  function easeOutExpo(t) {
    return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
  }

  function formatNumber(n) {
    return n.toLocaleString("en-US");
  }

  /* =========================================
     MODULE 3 — STORY CLUSTER ROTATION
     ========================================= */

  function initClusterRotation() {
    var titleElement = document.getElementById("clusterTitle");

    if (!titleElement) return;

    var clusters = [
      {
        title: "Apple Expands AI Strategy",
        sources: 32,
        articles: 147,
        impact: "High Impact",
        publishers: [
          "Reuters",
          "Bloomberg",
          "CNBC",
          "BBC",
          "The Verge",
        ],
        insights: [
          "New AI products announced",
          "Enterprise rollout expands",
          "Developer ecosystem grows",
        ],
      },
      {
        title: "Nvidia Earnings Surge",
        sources: 21,
        articles: 89,
        impact: "High Impact",
        publishers: [
          "Reuters",
          "Bloomberg",
          "CNBC",
          "WSJ",
          "Financial Times",
        ],
        insights: [
          "Revenue beats estimates",
          "AI chip demand accelerates",
          "Supply chain concerns ease",
        ],
      },
      {
        title: "US Election Updates",
        sources: 45,
        articles: 203,
        impact: "Critical",
        publishers: [
          "AP",
          "Reuters",
          "CNN",
          "BBC",
          "NPR",
        ],
        insights: [
          "Polling shifts detected",
          "Key state developments",
          "Policy positions evolve",
        ],
      },
      {
        title: "Singapore Housing Policy",
        sources: 12,
        articles: 42,
        impact: "Medium Impact",
        publishers: [
          "CNA",
          "Straits Times",
          "Bloomberg",
          "Reuters",
          "TODAY",
        ],
        insights: [
          "New cooling measures proposed",
          "HDB supply increases",
          "Market sentiment shifts",
        ],
      },
      {
        title: "Global Markets Rally",
        sources: 18,
        articles: 56,
        impact: "High Impact",
        publishers: [
          "Bloomberg",
          "Reuters",
          "CNBC",
          "Financial Times",
          "WSJ",
        ],
        insights: [
          "Indices reach new highs",
          "Bond yields stabilize",
          "Investor sentiment improves",
        ],
      },
      {
        title: "OpenAI Launches New Model",
        sources: 28,
        articles: 134,
        impact: "High Impact",
        publishers: [
          "The Verge",
          "TechCrunch",
          "Reuters",
          "Bloomberg",
          "Wired",
        ],
        insights: [
          "Performance benchmarks released",
          "Enterprise pricing announced",
          "Safety measures detailed",
        ],
      },
    ];

    var currentIndex = 0;
    var metricsContainer = document.querySelector(".cluster-metrics");
    var publisherNodes = document.querySelectorAll(".publisher-node");
    var insightCards = document.querySelectorAll(".insight-card");
    var clusterCard = document.querySelector(".cluster-card");

    function updateCluster() {
      var cluster = clusters[currentIndex];

      if (clusterCard) {
        clusterCard.style.opacity = "0";
        clusterCard.style.transform = "scale(0.96)";
      }

      deactivateAll();

      setTimeout(function () {
        titleElement.textContent = cluster.title;

        if (metricsContainer) {
          metricsContainer.innerHTML =
            "<span>" +
            cluster.sources +
            " Sources</span>" +
            "<span>" +
            cluster.articles +
            " Articles</span>" +
            "<span>" +
            cluster.impact +
            "</span>";
        }

        if (clusterCard) {
          clusterCard.style.opacity = "1";
          clusterCard.style.transform = "scale(1)";
        }

        animatePublishers(cluster.publishers);
        animateInsights(cluster.insights);
      }, 400);

      currentIndex = (currentIndex + 1) % clusters.length;
    }

    function deactivateAll() {
      publisherNodes.forEach(function (node) {
        node.classList.remove("active");
      });

      insightCards.forEach(function (card) {
        card.classList.remove("active");
      });
    }

    function animatePublishers(publishers) {
      publisherNodes.forEach(function (node, index) {
        setTimeout(function () {
          node.textContent = publishers[index] || node.textContent;
          node.classList.add("active");
        }, index * 120);
      });
    }

    function animateInsights(insights) {
      insightCards.forEach(function (card, index) {
        setTimeout(function () {
          card.textContent = insights[index] || card.textContent;
          card.classList.add("active");
        }, 600 + index * 180);
      });
    }

    if (clusterCard) {
      clusterCard.style.transition =
        "opacity 400ms ease, transform 400ms ease";
    }

    var prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReducedMotion) {
      updateCluster();
      return;
    }

    var clusterObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            updateCluster();
            startRotation();
            clusterObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.3 }
    );

    var stage = document.querySelector(".cluster-stage");
    if (stage) {
      clusterObserver.observe(stage);
    }

    var rotationInterval = null;

    function startRotation() {
      rotationInterval = setInterval(updateCluster, 5000);
    }

    document.addEventListener("visibilitychange", function () {
      if (document.hidden) {
        clearInterval(rotationInterval);
      } else {
        startRotation();
      }
    });
  }

  /* =========================================
     MODULE 4 — TOPIC UNIVERSE INTERACTION
     ========================================= */

  function initTopicInteraction() {
    var topicButtons = document.querySelectorAll(".topic-word");
    var infoElement = document.getElementById("topicInfo");

    if (!topicButtons.length || !infoElement) return;

    var topicDescriptions = {
      TECH: "2,342 active stories across AI, startups, cybersecurity, and devices.",
      FINANCE:
        "1,780 active stories across markets, earnings, crypto, and economics.",
      GLOBAL:
        "1,291 active stories across geopolitics, diplomacy, and regional affairs.",
      POLITICS:
        "985 active stories across domestic policy, elections, and governance.",
      CULTURE:
        "744 active stories across entertainment, internet culture, and media.",
    };

    var defaultText = infoElement.textContent;

    topicButtons.forEach(function (button) {
      button.addEventListener("mouseenter", function () {
        var topic = button.textContent.trim();
        var description = topicDescriptions[topic];

        if (description) {
          infoElement.textContent = description;
          infoElement.classList.add("active");
        }
      });

      button.addEventListener("mouseleave", function () {
        infoElement.textContent = defaultText;
        infoElement.classList.remove("active");
      });

      button.addEventListener("focus", function () {
        var topic = button.textContent.trim();
        var description = topicDescriptions[topic];

        if (description) {
          infoElement.textContent = description;
          infoElement.classList.add("active");
        }
      });

      button.addEventListener("blur", function () {
        infoElement.textContent = defaultText;
        infoElement.classList.remove("active");
      });
    });
  }

  /* =========================================
     MODULE 5 — SMOOTH SCROLL FOR NAV LINKS
     ========================================= */

  function initSmoothScroll() {
    var links = document.querySelectorAll('a[href^="#"]');

    links.forEach(function (link) {
      link.addEventListener("click", function (event) {
        var href = link.getAttribute("href");

        if (!href || href === "#") return;

        var target = document.querySelector(href);

        if (!target) return;

        event.preventDefault();

        var headerHeight =
          document.querySelector(".site-header")?.offsetHeight || 64;

        var targetPosition =
          target.getBoundingClientRect().top +
          window.scrollY -
          headerHeight -
          20;

        window.scrollTo({
          top: targetPosition,
          behavior: "smooth",
        });

        target.setAttribute("tabindex", "-1");
        target.focus({ preventScroll: true });
      });
    });
  }

  /* =========================================
     MODULE 6 — HEADER SCROLL BEHAVIOR
     ========================================= */

  function initHeaderScroll() {
    var header = document.querySelector(".site-header");

    if (!header) return;

    var lastScroll = 0;
    var ticking = false;

    function onScroll() {
      var currentScroll = window.scrollY;

      if (currentScroll > 120) {
        header.style.borderBottom = "1px solid var(--line)";
      } else {
        header.style.borderBottom = "1px solid transparent";
      }

      lastScroll = currentScroll;
      ticking = false;
    }

    window.addEventListener(
      "scroll",
      function () {
        if (!ticking) {
          requestAnimationFrame(onScroll);
          ticking = true;
        }
      },
      { passive: true }
    );

    header.style.borderBottom = "1px solid transparent";
    header.style.transition = "border-color 200ms ease";
  }

  /* =========================================
     MODULE 7 — COMPARISON ANIMATION
     ========================================= */

  function initComparisonAnimation() {
    var section = document.querySelector(".comparison");

    if (!section) return;

    var headlines = section.querySelectorAll(".headline-stack");
    var storyNode = section.querySelector(".story-node");

    if (!headlines.length || !storyNode) return;

    var prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReducedMotion) return;

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;

          headlines.forEach(function (headline, index) {
            headline.style.opacity = "0";
            headline.style.transform = "translateX(-12px)";
            headline.style.transition =
              "opacity 500ms ease, transform 500ms ease";

            setTimeout(function () {
              headline.style.opacity =
                1 - index * 0.18 + "";
              headline.style.transform = "translateX(0)";
            }, index * 150);
          });

          storyNode.style.opacity = "0";
          storyNode.style.transform = "scale(0.95)";
          storyNode.style.transition =
            "opacity 600ms ease, transform 600ms ease";

          setTimeout(function () {
            storyNode.style.opacity = "1";
            storyNode.style.transform = "scale(1)";
          }, headlines.length * 150 + 200);

          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.3 }
    );

    observer.observe(section);
  }

  /* =========================================
     MODULE 8 — PREVIEW HOVER INTERACTION
     ========================================= */

  function initPreviewInteraction() {
    var clusters = document.querySelectorAll(".preview-cluster");
    var detailTitle = document.querySelector(".preview-detail h4");
    var detailText = document.querySelector(".preview-detail p");

    if (!clusters.length || !detailTitle || !detailText) return;

    var previewData = [
      {
        title: "AI Summary",
        text: "Apple is expanding its enterprise AI strategy with new developer APIs and model improvements across its product line.",
      },
      {
        title: "AI Summary",
        text: "Nvidia reports record quarterly revenue driven by accelerating demand for AI training and inference chips.",
      },
      {
        title: "AI Summary",
        text: "Global markets rally as bond yields stabilize and investor sentiment improves across major indices.",
      },
    ];

    clusters.forEach(function (cluster, index) {
      cluster.addEventListener("mouseenter", function () {
        var data = previewData[index];

        if (!data) return;

        clusters.forEach(function (c) {
          c.style.background = "";
        });

        cluster.style.background = "var(--moss-light)";
        detailTitle.textContent = data.title;
        detailText.textContent = data.text;
      });

      cluster.addEventListener("mouseleave", function () {
        cluster.style.background = "";
      });
    });
  }

  /* =========================================
     MODULE 9 — KEYBOARD ACCESSIBILITY
     ========================================= */

  function initKeyboardAccessibility() {
    document.addEventListener("keydown", function (event) {
      if (event.key === "Tab") {
        document.body.classList.add("keyboard-nav");
      }
    });

    document.addEventListener("mousedown", function () {
      document.body.classList.remove("keyboard-nav");
    });
  }

  /* =========================================
     INITIALIZATION
     ========================================= */

  function init() {
    initScrollReveal();
    initCounters();
    initClusterRotation();
    initTopicInteraction();
    initSmoothScroll();
    initHeaderScroll();
    initComparisonAnimation();
    initPreviewInteraction();
    initKeyboardAccessibility();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
